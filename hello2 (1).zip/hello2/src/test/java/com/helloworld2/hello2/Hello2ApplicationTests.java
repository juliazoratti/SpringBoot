package com.helloworld2.hello2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hello2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
